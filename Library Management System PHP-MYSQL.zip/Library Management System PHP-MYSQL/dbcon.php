<?php
mysql_select_db('justin',mysql_connect('localhost','root',''))or die(mysql_error());
?>