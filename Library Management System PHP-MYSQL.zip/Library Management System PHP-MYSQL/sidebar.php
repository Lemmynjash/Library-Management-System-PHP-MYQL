			<div class="life-side-bar">
			<div class="hero-container">                  
			
					
			</div>
			
			
		
					
					
							<ul class="nav nav-tabs nav-stacked">
						<li class="">
						<a   href="books.php"><i class="icon-phone icon-large"></i>&nbsp;View Books</a>
						</li>
					</ul>
<strong>Address</strong>
<p>National Highway, Kenyatta Road. Nairobi,Kenya</p>
<p>Tel. nos.:+254706606894</p>
<p>+254706606894</p>
<p>Email:justineulemkurino@gmail.com</p>
 


			
			</div>
			
	<!-- vision student login -->
	<div id="vision" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header"><div class="alert alert-info"><strong>Vision</strong></div></div>
		<div class="modal-body">
		<p>By 2017 The Public Library is a center of reserach where stackholders,public members ,students are conscientiously involved in loning holistic 
					individuals committed to positively respond to the needs of the school, community and the country.</p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
		</div>
    </div>
	
	
				    <!-- mission student login -->
	<div id="mission" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header"><div class="alert alert-info"><strong>Mission</strong></div></div>
		<div class="modal-body">
		<p>
		To nurture public to become productive responsible citizens through the assistance of service - 
					oriented and highly competent internal and external stakeholders working in a harmonious relationship.
		</p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
		</div>
    </div>